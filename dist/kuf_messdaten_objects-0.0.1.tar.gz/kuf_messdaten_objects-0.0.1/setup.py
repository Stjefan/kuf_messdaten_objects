
# Anleitung
# https://www.tutorialsteacher.com/python/python-package

# Zum Installieren:
# pip install . 
from setuptools import setup
setup(name='kuf_messdaten_objects',
version='0.0.1',
description='Testing installation of Package',
url='#',
author='auth',
author_email='author@email.com',
license='MIT',
packages=['kuf_messdaten_objects'],
zip_safe=False)